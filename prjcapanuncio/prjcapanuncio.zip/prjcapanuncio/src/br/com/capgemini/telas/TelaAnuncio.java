/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.capgemini.telas;

/**
 *
 * @author verau
 */
import java.sql.*;
import br.com.capgemini.dal.ModuloConexao;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import static java.util.Date.parse;
import javax.swing.JOptionPane;

public class TelaAnuncio extends javax.swing.JInternalFrame {

    Connection conexao = null;
    //PreparedStatement e ResultSet são frameworks do pacote Java
    //e servem para preparar e executar as instruções Sql 
    PreparedStatement pst = null;
    ResultSet rs = null;

    private final SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

    /**
     * Creates new form TelaAnuncio
     */
    public TelaAnuncio() {
        initComponents();
        conexao = ModuloConexao.conector();
    }

    private void consultar() {
        String sql = "select * from tbl_anuncio where id_anuncio = ?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtAnuId.getText());
            rs = pst.executeQuery();
            if (rs.next()) {
                txtAnuNome.setText(rs.getString(2));
                txtAnuCliente.setText(rs.getString(3));
                //txtAnuInicio.setText(sdf.format(pst.g);
                txtAnuInicio.setText(sdf.format(rs.getDate(4)));
                txtAnuTermino.setText(sdf.format(rs.getDate(5)));
                txtAnuInv.setText(rs.getString(6));
            } else {
                JOptionPane.showMessageDialog(null, "Anúncio não cadastrado");
                //as linhas abaixo "limpam" os campos
                txtAnuNome.setText(null);
                txtAnuCliente.setText(null);
                txtAnuInicio.setText(null);
                txtAnuTermino.setText(null);
                txtAnuInv.setText(null);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    private void adicionar() {
        String sql = "insert into tbl_anuncio(id_anuncio, nome_anuncio, cliente_anuncio, dataInicio_anuncio, dataTermino_anuncio, investimentoDia_anuncio)"
                + " values(?,?,?,?,?,?)";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtAnuId.getText());
            pst.setString(2, txtAnuNome.getText());
            pst.setString(3, txtAnuCliente.getText());

            String dia = txtAnuInicio.getText().substring(0, 2);
            String mes = txtAnuInicio.getText().substring(3, 5);
            String ano = txtAnuInicio.getText().substring(6);
            String dataIniTab = ano + "-" + mes + "-" + dia;
            System.out.println(dataIniTab);
            pst.setString(4, dataIniTab);

            String diat = txtAnuTermino.getText().substring(0, 2);
            String mest = txtAnuTermino.getText().substring(3, 5);
            String anot = txtAnuTermino.getText().substring(6);
            String dataTermTab = anot + "-" + mest + "-" + diat;

            pst.setString(5, dataTermTab);
            pst.setString(6, txtAnuInv.getText());

            //Validação dos campos obrigatórios
            if ((txtAnuId.getText().isEmpty()) || (txtAnuNome.getText().isEmpty()) || (txtAnuCliente.getText().isEmpty()) || (txtAnuInicio.getText().isEmpty()) || (txtAnuTermino.getText().isEmpty()) || (txtAnuInv.getText().isEmpty())) {
                JOptionPane.showMessageDialog(null, "Preencha todos os campos obrigatórios");
            } else {

                //a linha abaixo atualiza a tabela de anúncios com os dados do formulário
                //a estrutura abaixo é usada para confirmar a inserção dos dados na tabela
                int adicionado = pst.executeUpdate();
                //a linha abaixo serve de apoio ao entendimento da lógica
                //System.out.println(adicionado);
                if (adicionado > 0) {
                    JOptionPane.showMessageDialog(null, "Anúncio adicionado com sucesso!");
                    txtAnuId.setText(null);
                    txtAnuNome.setText(null);
                    txtAnuCliente.setText(null);
                    txtAnuInicio.setText(null);
                    txtAnuTermino.setText(null);
                    txtAnuInv.setText(null);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    //criando o método para alterar dados do usuário
    private void alterar() {
        String sql = "update tbl_anuncio set nome_anuncio=?, cliente_anuncio=?, dataInicio_anuncio=?, dataTermino_anuncio=?, investimentoDia_anuncio=? where id_anuncio=?";

        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtAnuNome.getText());
            pst.setString(2, txtAnuCliente.getText());

            String dia = txtAnuInicio.getText().substring(0, 2);
            String mes = txtAnuInicio.getText().substring(3, 5);
            String ano = txtAnuInicio.getText().substring(6);
            String dataIniTab = ano + "-" + mes + "-" + dia;
            System.out.println(dataIniTab);
            pst.setString(3, dataIniTab);

            String diat = txtAnuTermino.getText().substring(0, 2);
            String mest = txtAnuTermino.getText().substring(3, 5);
            String anot = txtAnuTermino.getText().substring(6);
            String dataTermTab = anot + "-" + mest + "-" + diat;

            pst.setString(4, dataTermTab);
            pst.setString(5, txtAnuInv.getText());
            pst.setString(6, txtAnuId.getText());

            //Validação dos campos obrigatórios
            if ((txtAnuId.getText().isEmpty()) || (txtAnuNome.getText().isEmpty()) || (txtAnuCliente.getText().isEmpty()) || (txtAnuInicio.getText().isEmpty()) || (txtAnuTermino.getText().isEmpty()) || (txtAnuInv.getText().isEmpty())) {
                JOptionPane.showMessageDialog(null, "Preencha todos os campos obrigatórios");
            } else {

                //a linha abaixo atualiza a tabela de anúncios com os dados do formulário
                //a estrutura abaixo é usada para confirmar a inserção dos dados na tabela
                int adicionado = pst.executeUpdate();
                //a linha abaixo serve de apoio ao entendimento da lógica
                System.out.println(adicionado);
                if (adicionado > 0) {
                    JOptionPane.showMessageDialog(null, "Anúncio alterado com sucesso!");
                    txtAnuId.setText(null);
                    txtAnuNome.setText(null);
                    txtAnuCliente.setText(null);
                    txtAnuInicio.setText(null);
                    txtAnuTermino.setText(null);
                    txtAnuInv.setText(null);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    private void remover() {
        //a estrutura abaixo confirma a remoção do anúncio
        int confirma = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover este anúncio ?", "Atenção", JOptionPane.YES_NO_OPTION);
        if (confirma == JOptionPane.YES_OPTION) {
            String sql = "delete from tbl_anuncio where id_anuncio=?";
            try {
                pst = conexao.prepareStatement(sql);
                pst.setString(1, txtAnuId.getText());
                int apagado = pst.executeUpdate();
                if (apagado > 0) {
                    JOptionPane.showMessageDialog(null, "Anúncio removido com sucesso");
                    txtAnuId.setText(null);
                    txtAnuNome.setText(null);
                    txtAnuCliente.setText(null);
                    txtAnuInicio.setText(null);
                    txtAnuTermino.setText(null);
                    txtAnuInv.setText(null);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);

            }
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtAnuNome = new javax.swing.JTextField();
        txtAnuCliente = new javax.swing.JTextField();
        txtAnuInicio = new javax.swing.JTextField();
        txtAnuTermino = new javax.swing.JTextField();
        btnAnuCreate = new javax.swing.JButton();
        btnAnuRead = new javax.swing.JButton();
        btnAnuUpdate = new javax.swing.JButton();
        btnAnuDelete = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txtAnuId = new javax.swing.JTextField();
        txtAnuInv = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Cadastro de Anúncios");
        setPreferredSize(new java.awt.Dimension(630, 430));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("*Nome do Anúncio");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("*Nome do Cliente");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("*Data de início");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel5.setText("*Data de término");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel6.setText("*Investimento por dia - R$");

        txtAnuInicio.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txtAnuInicio.setToolTipText("DD/MM/AAAA");

        txtAnuTermino.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txtAnuTermino.setToolTipText("DD/MM/AAAA");
        txtAnuTermino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAnuTerminoActionPerformed(evt);
            }
        });

        btnAnuCreate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/capgemini/icones/create.png"))); // NOI18N
        btnAnuCreate.setToolTipText("Adicionar");
        btnAnuCreate.setPreferredSize(new java.awt.Dimension(80, 80));
        btnAnuCreate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnuCreateActionPerformed(evt);
            }
        });

        btnAnuRead.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/capgemini/icones/read.png"))); // NOI18N
        btnAnuRead.setToolTipText("Consultar");
        btnAnuRead.setPreferredSize(new java.awt.Dimension(80, 80));
        btnAnuRead.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnuReadActionPerformed(evt);
            }
        });

        btnAnuUpdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/capgemini/icones/update.png"))); // NOI18N
        btnAnuUpdate.setToolTipText("Alterar");
        btnAnuUpdate.setPreferredSize(new java.awt.Dimension(80, 80));
        btnAnuUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnuUpdateActionPerformed(evt);
            }
        });

        btnAnuDelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/br/com/capgemini/icones/delete.png"))); // NOI18N
        btnAnuDelete.setToolTipText("Remover");
        btnAnuDelete.setPreferredSize(new java.awt.Dimension(80, 80));
        btnAnuDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnuDeleteActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel7.setText("*Código do Anúncio");

        txtAnuId.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        txtAnuInv.setToolTipText("Utilize o ponto para casa decimal");

        jLabel1.setText("* Campos obrigatórios");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnAnuCreate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(76, 76, 76)
                        .addComponent(btnAnuRead, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(69, 69, 69)
                        .addComponent(btnAnuUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnAnuDelete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtAnuInicio)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE))
                                .addGap(121, 121, 121)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 94, Short.MAX_VALUE)
                                    .addComponent(txtAnuTermino))
                                .addGap(78, 78, 78)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 143, Short.MAX_VALUE)
                                    .addComponent(txtAnuInv)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7))
                                .addGap(27, 27, 27)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtAnuCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 408, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(txtAnuId, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(txtAnuNome, javax.swing.GroupLayout.PREFERRED_SIZE, 407, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addGap(61, 61, 61))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtAnuId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtAnuNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtAnuCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtAnuInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtAnuTermino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtAnuInv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAnuUpdate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAnuDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAnuRead, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAnuCreate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(73, 73, 73))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtAnuTerminoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAnuTerminoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAnuTerminoActionPerformed

    private void btnAnuReadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnuReadActionPerformed
        // Chamando o método consultar
        consultar();
    }//GEN-LAST:event_btnAnuReadActionPerformed

    private void btnAnuCreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnuCreateActionPerformed
        // Chamando o método adicionar
        adicionar();
    }//GEN-LAST:event_btnAnuCreateActionPerformed

    private void btnAnuUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnuUpdateActionPerformed
        // chamando o método alterar
        alterar();
    }//GEN-LAST:event_btnAnuUpdateActionPerformed

    private void btnAnuDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnuDeleteActionPerformed
        // chamando o método remover
        remover();
    }//GEN-LAST:event_btnAnuDeleteActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnuCreate;
    private javax.swing.JButton btnAnuDelete;
    private javax.swing.JButton btnAnuRead;
    private javax.swing.JButton btnAnuUpdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField txtAnuCliente;
    private javax.swing.JTextField txtAnuId;
    private javax.swing.JTextField txtAnuInicio;
    private javax.swing.JTextField txtAnuInv;
    private javax.swing.JTextField txtAnuNome;
    private javax.swing.JTextField txtAnuTermino;
    // End of variables declaration//GEN-END:variables
}
